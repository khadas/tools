# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'textWindow.ui'
##
## Created by: Qt User Interface Compiler version 6.4.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QSizePolicy, QTextBrowser, QVBoxLayout,
    QWidget)

class Ui_textWindow(object):
    def setupUi(self, textWindow):
        if not textWindow.objectName():
            textWindow.setObjectName(u"textWindow")
        textWindow.resize(1118, 518)
        self.verticalLayout = QVBoxLayout(textWindow)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.textBrowser = QTextBrowser(textWindow)
        self.textBrowser.setObjectName(u"textBrowser")

        self.verticalLayout.addWidget(self.textBrowser)


        self.retranslateUi(textWindow)

        QMetaObject.connectSlotsByName(textWindow)
    # setupUi

    def retranslateUi(self, textWindow):
        textWindow.setWindowTitle(QCoreApplication.translate("textWindow", u"Form", None))
    # retranslateUi

