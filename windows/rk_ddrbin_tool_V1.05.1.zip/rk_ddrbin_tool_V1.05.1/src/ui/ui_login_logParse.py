# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'login_logParse.ui'
##
## Created by: Qt User Interface Compiler version 6.4.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QComboBox, QFrame, QGridLayout,
    QGroupBox, QHBoxLayout, QHeaderView, QLabel,
    QLineEdit, QMainWindow, QMenuBar, QPushButton,
    QRadioButton, QSizePolicy, QStatusBar, QTableWidget,
    QTableWidgetItem, QVBoxLayout, QWidget)

class Ui_logParse(object):
    def setupUi(self, logParse):
        if not logParse.objectName():
            logParse.setObjectName(u"logParse")
        logParse.resize(1200, 642)
        sizePolicy = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(logParse.sizePolicy().hasHeightForWidth())
        logParse.setSizePolicy(sizePolicy)
        self.centralwidget = QWidget(logParse)
        self.centralwidget.setObjectName(u"centralwidget")
        self.gridLayout = QGridLayout(self.centralwidget)
        self.gridLayout.setObjectName(u"gridLayout")
        self.groupBox_Summary = QGroupBox(self.centralwidget)
        self.groupBox_Summary.setObjectName(u"groupBox_Summary")
        sizePolicy1 = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        sizePolicy1.setHorizontalStretch(3)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.groupBox_Summary.sizePolicy().hasHeightForWidth())
        self.groupBox_Summary.setSizePolicy(sizePolicy1)
        self.verticalLayout = QVBoxLayout(self.groupBox_Summary)
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.tableWidget_summary = QTableWidget(self.groupBox_Summary)
        self.tableWidget_summary.setObjectName(u"tableWidget_summary")

        self.verticalLayout.addWidget(self.tableWidget_summary)


        self.gridLayout.addWidget(self.groupBox_Summary, 3, 0, 1, 1)

        self.groupBox_Detail = QGroupBox(self.centralwidget)
        self.groupBox_Detail.setObjectName(u"groupBox_Detail")
        sizePolicy2 = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        sizePolicy2.setHorizontalStretch(5)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.groupBox_Detail.sizePolicy().hasHeightForWidth())
        self.groupBox_Detail.setSizePolicy(sizePolicy2)
        self.verticalLayout_2 = QVBoxLayout(self.groupBox_Detail)
        self.verticalLayout_2.setSpacing(0)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.tableWidget_detail = QTableWidget(self.groupBox_Detail)
        self.tableWidget_detail.setObjectName(u"tableWidget_detail")

        self.verticalLayout_2.addWidget(self.tableWidget_detail)


        self.gridLayout.addWidget(self.groupBox_Detail, 3, 1, 1, 1)

        self.frame_cfg = QFrame(self.centralwidget)
        self.frame_cfg.setObjectName(u"frame_cfg")
        sizePolicy3 = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.frame_cfg.sizePolicy().hasHeightForWidth())
        self.frame_cfg.setSizePolicy(sizePolicy3)
        self.frame_cfg.setMinimumSize(QSize(0, 0))
        self.frame_cfg.setFrameShape(QFrame.StyledPanel)
        self.frame_cfg.setFrameShadow(QFrame.Raised)
        self.gridLayout_3 = QGridLayout(self.frame_cfg)
        self.gridLayout_3.setSpacing(0)
        self.gridLayout_3.setObjectName(u"gridLayout_3")
        self.gridLayout_3.setContentsMargins(0, 0, 0, 0)
        self.frame_dramCfg = QFrame(self.frame_cfg)
        self.frame_dramCfg.setObjectName(u"frame_dramCfg")
        sizePolicy3.setHeightForWidth(self.frame_dramCfg.sizePolicy().hasHeightForWidth())
        self.frame_dramCfg.setSizePolicy(sizePolicy3)
        self.frame_dramCfg.setMinimumSize(QSize(0, 0))
        self.frame_dramCfg.setFrameShape(QFrame.StyledPanel)
        self.frame_dramCfg.setFrameShadow(QFrame.Raised)
        self.frame_dramCfg.setLineWidth(1)
        self.frame_dramCfg.setMidLineWidth(0)
        self.gridLayout_2 = QGridLayout(self.frame_dramCfg)
        self.gridLayout_2.setObjectName(u"gridLayout_2")
        self.gridLayout_2.setHorizontalSpacing(6)
        self.gridLayout_2.setVerticalSpacing(0)
        self.gridLayout_2.setContentsMargins(0, 0, 0, 0)
        self.label_dramType = QLabel(self.frame_dramCfg)
        self.label_dramType.setObjectName(u"label_dramType")

        self.gridLayout_2.addWidget(self.label_dramType, 1, 0, 1, 1)

        self.label_rankNum = QLabel(self.frame_dramCfg)
        self.label_rankNum.setObjectName(u"label_rankNum")

        self.gridLayout_2.addWidget(self.label_rankNum, 1, 2, 1, 1)

        self.comboBox_strideSize = QComboBox(self.frame_dramCfg)
        self.comboBox_strideSize.setObjectName(u"comboBox_strideSize")

        self.gridLayout_2.addWidget(self.comboBox_strideSize, 2, 1, 1, 1)

        self.comboBox_busWidth = QComboBox(self.frame_dramCfg)
        self.comboBox_busWidth.setObjectName(u"comboBox_busWidth")

        self.gridLayout_2.addWidget(self.comboBox_busWidth, 2, 3, 1, 1)

        self.label_busWidth = QLabel(self.frame_dramCfg)
        self.label_busWidth.setObjectName(u"label_busWidth")

        self.gridLayout_2.addWidget(self.label_busWidth, 2, 2, 1, 1)

        self.comboBox_chNum = QComboBox(self.frame_dramCfg)
        self.comboBox_chNum.setObjectName(u"comboBox_chNum")

        self.gridLayout_2.addWidget(self.comboBox_chNum, 0, 3, 1, 1)

        self.label_ddrcfg = QLabel(self.frame_dramCfg)
        self.label_ddrcfg.setObjectName(u"label_ddrcfg")

        self.gridLayout_2.addWidget(self.label_ddrcfg, 3, 0, 1, 1)

        self.label_chNum = QLabel(self.frame_dramCfg)
        self.label_chNum.setObjectName(u"label_chNum")

        self.gridLayout_2.addWidget(self.label_chNum, 0, 2, 1, 1)

        self.comboBox_chipName = QComboBox(self.frame_dramCfg)
        self.comboBox_chipName.setObjectName(u"comboBox_chipName")

        self.gridLayout_2.addWidget(self.comboBox_chipName, 0, 1, 1, 1)

        self.label_chip = QLabel(self.frame_dramCfg)
        self.label_chip.setObjectName(u"label_chip")

        self.gridLayout_2.addWidget(self.label_chip, 0, 0, 1, 1)

        self.label_totalCap = QLabel(self.frame_dramCfg)
        self.label_totalCap.setObjectName(u"label_totalCap")

        self.gridLayout_2.addWidget(self.label_totalCap, 3, 2, 1, 1)

        self.comboBox_ddrcfg = QComboBox(self.frame_dramCfg)
        self.comboBox_ddrcfg.setObjectName(u"comboBox_ddrcfg")

        self.gridLayout_2.addWidget(self.comboBox_ddrcfg, 3, 1, 1, 1)

        self.label_strideSize = QLabel(self.frame_dramCfg)
        self.label_strideSize.setObjectName(u"label_strideSize")

        self.gridLayout_2.addWidget(self.label_strideSize, 2, 0, 1, 1)

        self.comboBox_rankNum = QComboBox(self.frame_dramCfg)
        self.comboBox_rankNum.setObjectName(u"comboBox_rankNum")

        self.gridLayout_2.addWidget(self.comboBox_rankNum, 1, 3, 1, 1)

        self.comboBox_dramType = QComboBox(self.frame_dramCfg)
        self.comboBox_dramType.setObjectName(u"comboBox_dramType")

        self.gridLayout_2.addWidget(self.comboBox_dramType, 1, 1, 1, 1)

        self.comboBox_totalCap = QComboBox(self.frame_dramCfg)
        self.comboBox_totalCap.setObjectName(u"comboBox_totalCap")

        self.gridLayout_2.addWidget(self.comboBox_totalCap, 3, 3, 1, 1)


        self.gridLayout_3.addWidget(self.frame_dramCfg, 0, 0, 1, 1)

        self.frame_toolCfg = QFrame(self.frame_cfg)
        self.frame_toolCfg.setObjectName(u"frame_toolCfg")
        sizePolicy3.setHeightForWidth(self.frame_toolCfg.sizePolicy().hasHeightForWidth())
        self.frame_toolCfg.setSizePolicy(sizePolicy3)
        self.frame_toolCfg.setMinimumSize(QSize(600, 0))
        self.frame_toolCfg.setFrameShape(QFrame.StyledPanel)
        self.frame_toolCfg.setFrameShadow(QFrame.Raised)
        self.lineEdit_logFp = QLineEdit(self.frame_toolCfg)
        self.lineEdit_logFp.setObjectName(u"lineEdit_logFp")
        self.lineEdit_logFp.setGeometry(QRect(190, 0, 251, 20))
        self.label_rk_logo = QLabel(self.frame_toolCfg)
        self.label_rk_logo.setObjectName(u"label_rk_logo")
        self.label_rk_logo.setGeometry(QRect(490, 10, 90, 45))
        self.horizontalLayoutWidget = QWidget(self.frame_toolCfg)
        self.horizontalLayoutWidget.setObjectName(u"horizontalLayoutWidget")
        self.horizontalLayoutWidget.setGeometry(QRect(70, 40, 198, 22))
        self.horizontalLayout = QHBoxLayout(self.horizontalLayoutWidget)
        self.horizontalLayout.setSpacing(0)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.radioButton_buffA = QRadioButton(self.horizontalLayoutWidget)
        self.radioButton_buffA.setObjectName(u"radioButton_buffA")

        self.horizontalLayout.addWidget(self.radioButton_buffA)

        self.radioButton_buffB = QRadioButton(self.horizontalLayoutWidget)
        self.radioButton_buffB.setObjectName(u"radioButton_buffB")

        self.horizontalLayout.addWidget(self.radioButton_buffB)

        self.pushButton_tip = QPushButton(self.frame_toolCfg)
        self.pushButton_tip.setObjectName(u"pushButton_tip")
        self.pushButton_tip.setGeometry(QRect(0, 60, 71, 21))
        self.pushButton_logFp = QPushButton(self.frame_toolCfg)
        self.pushButton_logFp.setObjectName(u"pushButton_logFp")
        self.pushButton_logFp.setGeometry(QRect(440, 0, 31, 21))
        self.verticalLayoutWidget = QWidget(self.frame_toolCfg)
        self.verticalLayoutWidget.setObjectName(u"verticalLayoutWidget")
        self.verticalLayoutWidget.setGeometry(QRect(70, 0, 111, 48))
        self.verticalLayout_3 = QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout_3.setSpacing(0)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.radioButton_stress = QRadioButton(self.verticalLayoutWidget)
        self.radioButton_stress.setObjectName(u"radioButton_stress")

        self.verticalLayout_3.addWidget(self.radioButton_stress)

        self.radioButton_mem = QRadioButton(self.verticalLayoutWidget)
        self.radioButton_mem.setObjectName(u"radioButton_mem")

        self.verticalLayout_3.addWidget(self.radioButton_mem)

        self.label_type = QLabel(self.frame_toolCfg)
        self.label_type.setObjectName(u"label_type")
        self.label_type.setGeometry(QRect(0, 0, 61, 16))
        self.pushButton_confirm = QPushButton(self.frame_toolCfg)
        self.pushButton_confirm.setObjectName(u"pushButton_confirm")
        self.pushButton_confirm.setGeometry(QRect(400, 30, 71, 41))

        self.gridLayout_3.addWidget(self.frame_toolCfg, 0, 1, 1, 1)

        self.frame_hashCfg = QFrame(self.frame_cfg)
        self.frame_hashCfg.setObjectName(u"frame_hashCfg")
        sizePolicy4 = QSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        sizePolicy4.setHorizontalStretch(0)
        sizePolicy4.setVerticalStretch(0)
        sizePolicy4.setHeightForWidth(self.frame_hashCfg.sizePolicy().hasHeightForWidth())
        self.frame_hashCfg.setSizePolicy(sizePolicy4)
        self.frame_hashCfg.setMinimumSize(QSize(1100, 20))
        self.frame_hashCfg.setFrameShape(QFrame.StyledPanel)
        self.frame_hashCfg.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_2 = QHBoxLayout(self.frame_hashCfg)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.label_ddrcfg_hashInfo = QLabel(self.frame_hashCfg)
        self.label_ddrcfg_hashInfo.setObjectName(u"label_ddrcfg_hashInfo")

        self.horizontalLayout_2.addWidget(self.label_ddrcfg_hashInfo)

        self.lineEdit_hashInfo = QLineEdit(self.frame_hashCfg)
        self.lineEdit_hashInfo.setObjectName(u"lineEdit_hashInfo")
        sizePolicy5 = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        sizePolicy5.setHorizontalStretch(0)
        sizePolicy5.setVerticalStretch(0)
        sizePolicy5.setHeightForWidth(self.lineEdit_hashInfo.sizePolicy().hasHeightForWidth())
        self.lineEdit_hashInfo.setSizePolicy(sizePolicy5)

        self.horizontalLayout_2.addWidget(self.lineEdit_hashInfo)


        self.gridLayout_3.addWidget(self.frame_hashCfg, 1, 0, 1, 2)

        self.frame = QFrame(self.frame_cfg)
        self.frame.setObjectName(u"frame")
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)

        self.gridLayout_3.addWidget(self.frame, 0, 2, 2, 1)


        self.gridLayout.addWidget(self.frame_cfg, 0, 0, 3, 2)

        logParse.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(logParse)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 1200, 22))
        logParse.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(logParse)
        self.statusbar.setObjectName(u"statusbar")
        logParse.setStatusBar(self.statusbar)

        self.retranslateUi(logParse)

        QMetaObject.connectSlotsByName(logParse)
    # setupUi

    def retranslateUi(self, logParse):
        logParse.setWindowTitle(QCoreApplication.translate("logParse", u"MainWindow", None))
        self.groupBox_Summary.setTitle(QCoreApplication.translate("logParse", u"Summary", None))
        self.groupBox_Detail.setTitle(QCoreApplication.translate("logParse", u"Detail", None))
        self.label_dramType.setText(QCoreApplication.translate("logParse", u"DRAM\u7c7b\u578b/DRAM Type :", None))
        self.label_rankNum.setText(QCoreApplication.translate("logParse", u"\u7247\u9009\u6570(CS)/Rank Num :", None))
        self.label_busWidth.setText(QCoreApplication.translate("logParse", u"\u4f4d\u5bbd/Bus width :", None))
        self.label_ddrcfg.setText(QCoreApplication.translate("logParse", u"DDR config : (?)", None))
        self.label_chNum.setText(QCoreApplication.translate("logParse", u"\u901a\u9053\u6570/Channel Num :", None))
        self.label_chip.setText(QCoreApplication.translate("logParse", u"\u4e3b\u63a7\u578b\u53f7/Chip Name :", None))
        self.label_totalCap.setText(QCoreApplication.translate("logParse", u"\u603b\u5bb9\u91cf/Total Cap(MB) :", None))
        self.label_strideSize.setText(QCoreApplication.translate("logParse", u"\u4ea4\u7ec7\u7c92\u5ea6/Stride Size(B) :(?)", None))
        self.lineEdit_logFp.setText("")
        self.lineEdit_logFp.setPlaceholderText(QCoreApplication.translate("logParse", u"\u8bf7\u9009\u62e9\u6216\u8f93\u5165\u6587\u4ef6\u8def\u5f84/log file path", None))
        self.label_rk_logo.setText(QCoreApplication.translate("logParse", u"Rockchip", None))
        self.radioButton_buffA.setText(QCoreApplication.translate("logParse", u"Buffer_A", None))
        self.radioButton_buffB.setText(QCoreApplication.translate("logParse", u"Buffer_B", None))
        self.pushButton_tip.setText(QCoreApplication.translate("logParse", u"\u53c2\u6570\u8bf4\u660e", None))
        self.pushButton_logFp.setText(QCoreApplication.translate("logParse", u"...", None))
        self.radioButton_stress.setText(QCoreApplication.translate("logParse", u"Stressapptest", None))
        self.radioButton_mem.setText(QCoreApplication.translate("logParse", u"Memtester", None))
        self.label_type.setText(QCoreApplication.translate("logParse", u"\u7c7b\u578b/Type:", None))
        self.pushButton_confirm.setText(QCoreApplication.translate("logParse", u"\u786e\u8ba4\n"
"Confirm", None))
        self.label_ddrcfg_hashInfo.setText(QCoreApplication.translate("logParse", u"Hash Info :(?)", None))
    # retranslateUi

