# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'login.ui'
##
## Created by: Qt User Interface Compiler version 6.4.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QLabel, QMainWindow, QMenuBar,
    QPushButton, QSizePolicy, QStatusBar, QWidget)

class Ui_LoginWindow(object):
    def setupUi(self, LoginWindow):
        if not LoginWindow.objectName():
            LoginWindow.setObjectName(u"LoginWindow")
        LoginWindow.resize(532, 396)
        self.centralwidget = QWidget(LoginWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.pushButton_ddrBinTool = QPushButton(self.centralwidget)
        self.pushButton_ddrBinTool.setObjectName(u"pushButton_ddrBinTool")
        self.pushButton_ddrBinTool.setGeometry(QRect(170, 90, 191, 24))
        font = QFont()
        font.setBold(False)
        self.pushButton_ddrBinTool.setFont(font)
        self.pushButton_ddrStressLogTool = QPushButton(self.centralwidget)
        self.pushButton_ddrStressLogTool.setObjectName(u"pushButton_ddrStressLogTool")
        self.pushButton_ddrStressLogTool.setGeometry(QRect(170, 130, 191, 24))
        self.label_rk_logo = QLabel(self.centralwidget)
        self.label_rk_logo.setObjectName(u"label_rk_logo")
        self.label_rk_logo.setGeometry(QRect(430, 290, 93, 45))
        LoginWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(LoginWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 532, 22))
        LoginWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(LoginWindow)
        self.statusbar.setObjectName(u"statusbar")
        LoginWindow.setStatusBar(self.statusbar)

        self.retranslateUi(LoginWindow)

        QMetaObject.connectSlotsByName(LoginWindow)
    # setupUi

    def retranslateUi(self, LoginWindow):
        LoginWindow.setWindowTitle(QCoreApplication.translate("LoginWindow", u"MainWindow", None))
        self.pushButton_ddrBinTool.setText(QCoreApplication.translate("LoginWindow", u"DDR BIN\u4fee\u6539\u5de5\u5177", None))
        self.pushButton_ddrStressLogTool.setText(QCoreApplication.translate("LoginWindow", u"DDR \u538b\u6d4blog\u6587\u4ef6\u5206\u6790\u5de5\u5177", None))
        self.label_rk_logo.setText(QCoreApplication.translate("LoginWindow", u"rockchip logo", None))
    # retranslateUi

